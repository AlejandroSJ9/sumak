export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Products />
        <ContactForm />
      </main>
    </div>
  )
}

import Header from "../components/header"
import Hero from "../components/hero"
import Products from "../components/products"
import ContactForm from "../components/contact-form"


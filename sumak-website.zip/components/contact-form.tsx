"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Send } from 'lucide-react'

const ContactForm = () => {
  return (
    <section id="contacto" className="py-24 bg-gray-50">
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tighter mb-4">Contáctanos</h2>
            <p className="text-lg text-gray-600 mb-8">
              ¿Interesado en nuestros productos? Completa el formulario y nos pondremos en contacto contigo pronto.
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Send className="h-5 w-5 text-[#7C3AED]" />
                <span>info@sumakfruit.com</span>
              </div>
            </div>
          </div>
          <Card>
            <CardHeader>
              <h3 className="text-2xl font-semibold">Envíanos un mensaje</h3>
              <p className="text-gray-600">
                Completa el formulario para iniciar una conversación
              </p>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Input placeholder="Nombre" />
                  </div>
                  <div className="space-y-2">
                    <Input placeholder="Correo electrónico" type="email" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Textarea placeholder="Tu mensaje" className="min-h-[100px]" />
                </div>
                <Button type="submit" className="w-full bg-[#7C3AED] hover:bg-[#7C3AED]/90">
                  Enviar mensaje
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

export default ContactForm


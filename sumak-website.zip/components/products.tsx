"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import Image from "next/image"

const Products = () => {
  const products = [
    {
      name: "Gulupa",
      description: "Fruta exótica de sabor único y dulce, rica en antioxidantes.",
      image: "/placeholder.svg"
    },
    {
      name: "Maracuyá",
      description: "Fruta tropical aromática con sabor intenso y refrescante.",
      image: "/placeholder.svg"
    },
    {
      name: "Uchuva",
      description: "Pequeña fruta dorada con propiedades antioxidantes.",
      image: "/placeholder.svg"
    },
    {
      name: "Granadilla",
      description: "Fruta dulce y jugosa, perfecta para consumo directo.",
      image: "/placeholder.svg"
    }
  ]

  return (
    <section id="productos" className="py-24 bg-gray-50">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter mb-4">Nuestros Productos</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Descubre nuestra selección de frutas exóticas colombianas, cultivadas con amor y cuidado por nuestros agricultores.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card key={product.name} className="overflow-hidden">
              <CardHeader className="p-0">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  width={400}
                  height={300}
                  className="w-full aspect-video object-cover"
                />
              </CardHeader>
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">{product.name}</h3>
                <p className="text-gray-600">{product.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Products


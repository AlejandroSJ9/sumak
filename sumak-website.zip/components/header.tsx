"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu } from 'lucide-react'
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet"

const Header = () => {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2">
            <div className="relative w-[48px] h-[48px]">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-AIb9DPZ8MUKTQyU7nDW4IHR6750BAE.png"
                alt="Sumak Logo"
                width={48}
                height={48}
                className="object-contain"
              />
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#inicio" className="text-sm font-medium hover:text-[#7C3AED]">
              Inicio
            </Link>
            <Link href="#nosotros" className="text-sm font-medium hover:text-[#7C3AED]">
              Nosotros
            </Link>
            <Link href="#productos" className="text-sm font-medium hover:text-[#7C3AED]">
              Productos
            </Link>
            <Link href="#sostenibilidad" className="text-sm font-medium hover:text-[#7C3AED]">
              Sostenibilidad
            </Link>
            <Link href="#contacto" className="text-sm font-medium hover:text-[#7C3AED]">
              Contacto
            </Link>
          </nav>
        </div>
        
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Abrir menú</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="flex flex-col gap-4">
                <Link href="#inicio" className="text-lg font-medium">
                  Inicio
                </Link>
                <Link href="#nosotros" className="text-lg font-medium">
                  Nosotros
                </Link>
                <Link href="#productos" className="text-lg font-medium">
                  Productos
                </Link>
                <Link href="#sostenibilidad" className="text-lg font-medium">
                  Sostenibilidad
                </Link>
                <Link href="#contacto" className="text-lg font-medium">
                  Contacto
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </div>

        <Button size="sm" className="hidden md:inline-flex bg-[#7C3AED] hover:bg-[#7C3AED]/90 text-white">
          Contáctanos
        </Button>
      </div>
    </header>
  )
}

export default Header


import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Leaf, Users, Globe, Shield } from 'lucide-react'

const features = [
  {
    title: "Agricultura Sostenible",
    description: "Implementamos prácticas agrícolas que respetan el medio ambiente y garantizan la calidad de nuestros productos.",
    icon: Leaf
  },
  {
    title: "Comercio Justo",
    description: "Trabajamos directamente con agricultores locales, asegurando precios justos y condiciones laborales dignas.",
    icon: Users
  },
  {
    title: "Impacto Global",
    description: "Llevamos lo mejor de Colombia al mundo, promoviendo nuestra cultura y productos en mercados internacionales.",
    icon: Globe
  },
  {
    title: "Certificación de Calidad",
    description: "Cumplimos con los más altos estándares internacionales de calidad y seguridad alimentaria.",
    icon: Shield
  }
]

export default function Sustainability() {
  return (
    <section id="sostenibilidad" className="py-24">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter mb-4">Compromiso con la Sostenibilidad</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Nuestro compromiso va más allá de la exportación de frutas. Trabajamos por un futuro sostenible y justo.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature) => (
            <Card key={feature.title}>
              <CardHeader>
                <feature.icon className="h-12 w-12 text-primary mb-4" />
                <CardTitle className="text-xl mb-2">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}


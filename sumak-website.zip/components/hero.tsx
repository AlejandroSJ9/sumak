"use client"

import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

const Hero = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-gradient-to-b from-white to-purple-50">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 opacity-10">
          {Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className="absolute"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              <div className="w-64 h-64 rounded-full bg-[#7C3AED] blur-3xl" />
            </div>
          ))}
        </div>
      </div>

      <div className="container relative z-10 mx-auto px-4">
        <div className="text-center max-w-4xl mx-auto">
          <div className="mb-8 flex justify-center">
            <div className="relative w-[120px] h-[120px]">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-AIb9DPZ8MUKTQyU7nDW4IHR6750BAE.png"
                alt="Sumak Logo"
                width={120}
                height={120}
                className="object-contain"
              />
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 bg-gradient-to-r from-[#7C3AED] to-[#22C55E] bg-clip-text text-transparent">
            Llevamos lo mejor de Colombia al mundo
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-2xl mx-auto">
            Frutas exóticas de la más alta calidad, cultivadas con amor y compromiso por agricultores colombianos
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-[#7C3AED] hover:bg-[#7C3AED]/90 text-white px-8 py-6 text-lg"
            >
              <Link href="#contacto">
                Conócenos
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-[#7C3AED] text-[#7C3AED] hover:bg-[#7C3AED]/10 px-8 py-6 text-lg"
            >
              <Link href="#productos">
                Ver Productos
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
    </section>
  )
}

export default Hero


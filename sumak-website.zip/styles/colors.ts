export const colors = {
  primary: {
    DEFAULT: '#7C3AED', // Purple from logo
    foreground: '#FFFFFF',
  },
  secondary: {
    DEFAULT: '#22C55E', // Green from logo
    foreground: '#FFFFFF',
  },
  accent: {
    DEFAULT: '#F59E0B', // Yellow/Orange from logo
    foreground: '#000000',
  }
}

